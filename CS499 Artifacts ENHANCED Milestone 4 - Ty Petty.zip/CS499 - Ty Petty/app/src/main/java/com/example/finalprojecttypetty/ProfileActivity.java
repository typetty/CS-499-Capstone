package com.example.finalprojecttypetty;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {
    EditText newUsernameField;
    EditText newPasswordField;
    Button submitNewUsername;
    Button submitNewPassword;
    TextView errorUsername;
    TextView errorPassword;
    // Service
    UserService userService;
    int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page); // <-- your profile xml name

        // Get logged in user in the session
        currentUserId = getIntent().getIntExtra(SQLiteManager.LOGIN_EXTRA, -1);

        // Initialize userService class instance
        userService = new UserService(this);

        // Find all the UI elements to use in the code
        newUsernameField = findViewById(R.id.newUsernameField);
        newPasswordField = findViewById(R.id.newPasswordField);
        submitNewUsername = findViewById(R.id.submitNewUsername);
        submitNewPassword = findViewById(R.id.submitNewPassword);
        errorUsername = findViewById(R.id.errorUsername);
        errorPassword = findViewById(R.id.errorPassword);
    }

    // |-----------------|
    // | UPDATE USERNAME |
    // |-----------------|
    public void onClickUpdateUsername(View view) {
        // Hide the errorUsername element by default
        errorUsername.setVisibility(View.INVISIBLE);

        // get the new username and update it in the userService Class
        String newUsername = newUsernameField.getText().toString();
        UserService.UserResult result = userService.updateUsername(currentUserId, newUsername);

        // if an error occurs while updating, return an error message.
        if (!result.success) {
            showError(errorUsername, result.errorMessage);
            return;
        }

        showSuccess(errorUsername, "Username was updated successfully!");

    }

    // |-----------------|
    // | UPDATE PASSWORD |
    // |-----------------|
    public void onClickUpdatePassword(View view) {
        // Hide the errorPassword element by default
        errorPassword.setVisibility(View.INVISIBLE);

        // get the new password and update it in the userService Class
        String newPassword = newPasswordField.getText().toString();
        UserService.UserResult result = userService.updatePassword(currentUserId, newPassword);

        // if an error occurs while updating, return an error message.
        if (!result.success) {
            showError(errorPassword, result.errorMessage);
            return;
        }

        showSuccess(errorPassword, "Password was updated successfully!");
    }

    // Helper methods to show error messages and success messages.
    private void showError(TextView view, String message) {
        view.setText(message);
        view.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        view.setVisibility(View.VISIBLE);
    }

    private void showSuccess(TextView view, String message) {
        view.setText(message);
        view.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        view.setVisibility(View.VISIBLE);
    }
}