package com.example.finalprojecttypetty;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.util.Log;
import android.view.Window;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity {
    private ListView gridView;
    Button profileButton;
    private int currentUserId;
    private EventAdapter eventAdapter;
    private EditText searchText;
    private ImageButton searchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Remove the title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();

        // Set content view
        setContentView(R.layout.list_view);
        gridView = findViewById(R.id.gridView);
        profileButton = findViewById(R.id.profileButton);
        searchText = findViewById(R.id.searchText);
        searchButton = findViewById(R.id.searchButton);


        // Initial methods to call
        checkForUser();
        loadDBData(); // Make sure this line is above the setEventAdapter() as that needs the db data
        setEventAdapter();
        onItemClickListener();

        // Create an event listener if the search button is clicked
        searchButton.setOnClickListener(v -> searchEventList());

        // Make an event listener if the profile button is clicked to open the profile page
        profileButton.setOnClickListener(v -> {
            Intent intent =
                    new Intent(EventListActivity.this, ProfileActivity.class);
            intent.putExtra(SQLiteManager.LOGIN_EXTRA, currentUserId);
            startActivity(intent);
        });

    }

    // Check for the current user
    private void checkForUser() {
        Intent prevIntent = getIntent();
        currentUserId = prevIntent.getIntExtra(SQLiteManager.LOGIN_EXTRA, -1);

        if (currentUserId == -1) {
            finish();
        }
    }

    // Load in the initial data from the db
    private void loadDBData() {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.populateEventListArray(currentUserId);
    }

    private void setEventAdapter() {
//        Log.d("TP", "ListView UserId: " + currentUserId);
        eventAdapter = new EventAdapter(EventListActivity.this, Event.activeEvents());
        gridView.setAdapter(eventAdapter);
    }

    // On new fab button click
    public void onNewClick(View view) {
        Intent editIntent = new Intent(EventListActivity.this, EditEventActivity.class);
        editIntent.putExtra(SQLiteManager.LOGIN_EXTRA, currentUserId);
        startActivity(editIntent);
    }

    // Need to refresh the page when you return after adding a new event
    @Override
    protected void onResume() {
        super.onResume();
        setEventAdapter(); // Refreshes the ListView with the latest events
    }

    // Allow the user to edit an Event if clicked
    private void onItemClickListener() {
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Event selectedEvent = (Event) gridView.getItemAtPosition(position);
                Intent editEventIntent = new Intent(EventListActivity.this, EditEventActivity.class);
                editEventIntent.putExtra(Event.EVENT_EDIT_EXTRA, selectedEvent.getId());
                editEventIntent.putExtra(SQLiteManager.LOGIN_EXTRA, currentUserId);
                startActivity(editEventIntent);
            }
        });
    }

    // Show pop up page to ask for SMS permissions
    public void onNotificationsFABClick(View view) {
        Intent smsIntent = new Intent(EventListActivity.this, SMSPrompt.class);
        startActivity(smsIntent);
    }

    // Create a search function
    private void searchEventList() {
        String query = searchText.getText().toString().trim();

        // Make a safety in case the eventAdapter isn't coming back. This way the app doesn't crash
        if (eventAdapter == null) {
            return;
        }

        // if the query is empty, return the whole event list on search
        if (query.isEmpty()) {
            eventAdapter.updateEvents(Event.activeEvents());
            return;
        }

        // Update the event lists to show the queried event list
        eventAdapter.updateEvents(Event.searchEvents(query));
    }
}
