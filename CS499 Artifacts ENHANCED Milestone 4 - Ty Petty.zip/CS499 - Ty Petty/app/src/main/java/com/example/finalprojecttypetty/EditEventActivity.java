package com.example.finalprojecttypetty;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {
    // Declare global variables
    private TextView editTitle;
    private EditText editName;
    private EditText editLocation;
    private EditText editDate;
    private Event selectedEvent;
    private ImageButton deleteButton;
    private int currentUserId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Remove the title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();

        // Set content view
        setContentView(R.layout.edit_event);

        // Find the page attributes
        editName = findViewById(R.id.editTextEventName);
        editLocation = findViewById(R.id.editTextLocation);
        editDate = findViewById(R.id.editTextDate);
        deleteButton = findViewById(R.id.buttonDelete);
        editTitle = findViewById(R.id.editTitle);

        // Functions to call on create
        checkForUser();
        checkForEdit();

    }

    // Check for the current user
    private void checkForUser() {
        Intent prevIntent = getIntent();
        currentUserId = prevIntent.getIntExtra(SQLiteManager.LOGIN_EXTRA, -1);

        if (currentUserId == -1) {
            finish();
        }
    }

    // Check if we are editing or creating a record
    private void checkForEdit() {
        Intent prevIntent = getIntent();
        int parmId = prevIntent.getIntExtra(Event.EVENT_EDIT_EXTRA, -1);
        selectedEvent = Event.getEventPerId(parmId);

        if (selectedEvent != null) {
            editTitle.setText("Edit Event");
            editName.setText(selectedEvent.getName());
            editLocation.setText(selectedEvent.getLocation());
            editDate.setText(selectedEvent.getDate().toString());
            deleteButton.setVisibility(View.VISIBLE);
        }
    }

    // Cancel if the user clicks the cancel button
    public void onClickCancel(View view) {
        // Go back to the list view page. The fields should automatically clear when you next go to the page.
        finish();
    }

    // Save the event if the user hits save
    public void onClickSave(View view) {
        // Set up the db
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        // Get all the variables
        String name = editName.getText().toString();
        String location = editLocation.getText().toString();
        String date = editDate.getText().toString();
        int userId = currentUserId;

        if (selectedEvent == null) {
            // create the new id
            int id = Event.eventArrayList.size();
            // Create a new event object
            Event newEvent = new Event(id, userId, name, location, date);
            Event.eventArrayList.add(newEvent);
            sqLiteManager.addEventToDB(newEvent);
        } else {
            // update the existing record
            selectedEvent.setLocation(location);
            selectedEvent.setName(name);
            selectedEvent.setDate(date);
            sqLiteManager.updateEventToDB(selectedEvent);
        }
        finish();
    }

    // When a note is deleted
    public void onClickDelete(View view) {
        selectedEvent.setDelInd(true);
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.updateEventToDB(selectedEvent);
        finish();
    }
}
