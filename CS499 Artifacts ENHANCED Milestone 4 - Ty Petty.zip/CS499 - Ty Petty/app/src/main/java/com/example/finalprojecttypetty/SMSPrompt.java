package com.example.finalprojecttypetty;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SMSPrompt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set content view
        setContentView(R.layout.sms_popup);
    }

    // On click for deny and allow
    public void smsAllowOnClick(View view) {
        finish(); // Return to main page
    }

}
