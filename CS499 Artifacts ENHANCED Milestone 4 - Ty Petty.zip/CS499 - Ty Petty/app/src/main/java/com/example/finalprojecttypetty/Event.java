package com.example.finalprojecttypetty;

import java.util.ArrayList;
import java.util.HashMap;

public class Event {
    // Attributes needed for the an event object
    public static ArrayList<Event> eventArrayList = new ArrayList<>();
    public static HashMap<Integer, Event> eventMap = new HashMap<>();
//    public static ArrayList<Event> activeEventsList = new ArrayList<>();
    public static String EVENT_EDIT_EXTRA = "editEvent";
    private int id;
    private int userId;
    private String name;
    private String location;
    private String date;
    private boolean delInd;

    // Event constructors
    public Event(int id, int userId, String name, String location, String date) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.location = location;
        this.date = date;
        this.delInd = false;

        // Make sure we add this to the hash map to make searching efficient
        eventMap.put(this.id, this);
    }

    public Event(int id, int userId, String name, String location, String date, boolean delInd) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.location = location;
        this.date = date;
        this.delInd = delInd;

        // Make sure we add this to the hash map to make searching efficient
        eventMap.put(this.id, this);
    }

    // Find the event per the id
    public static Event getEventPerId(int parmId) {
        return eventMap.get(parmId);
    }

    // Get all non deleted events in the list
    public static ArrayList<Event> activeEvents() {
        ArrayList<Event> activeEventsList = new ArrayList<>();
        for (Event event : eventArrayList) {
            if (!event.getDelInd()) {
                activeEventsList.add(event);
            }
        }
        return activeEventsList;
    }

    // Create a function for the user to search through the events
    public static ArrayList<Event> searchEvents(String query) {
        ArrayList<Event> results = new ArrayList<>();

        // If the query is null or empty, don't do anything
        if (query == null || query.trim().isEmpty())
            return results;

        // Make the query more applicable by making it lowercase and then splitting it up at the spaces to get keywords
        String lowerQuery = query.toLowerCase().trim();
        String[] keywords = lowerQuery.split("\\s+");

        // Create a score map to rank the search results on the best match
        HashMap<Event, Integer> scoreMap = new HashMap<>();

        // Search through all the events on the list
        for (Event event : eventArrayList) {
            if (event.getDelInd()) continue;

            // make the event name lower case to match better to the keywords and split it to individual words for later use
            String eventName = event.getName().toLowerCase();
            String[] eventNameWords = eventName.split("\\s+");

            // determine the score for the search results
            int score = 0;
            for (String word : keywords) {
                if (eventName.contains(word)) { // check if the keyword is contained
                    score += 1;
                }
                if (eventName.startsWith(word)) { // check if it starts with the keyword
                    score += 5;
                }
                if (eventName.equalsIgnoreCase(query)) { // If it is an exact match, give it the most points
                    score += 1000;
                }
                for (String eventWord : eventNameWords) { // if it contains the word exactly give it more points than contains
                    if (eventWord.equals(word)) {
                        score += 10;
                    }
                }
            }
            // if the score is greater than 0 add it to the list or score map. This means the search matched.
            if (score > 0) {
                scoreMap.put(event, score);
            }
        }

        // add the score map elements to the results and then sort them by most points to least
        results.addAll(scoreMap.keySet());
        results.sort((event1, event2) -> Integer.compare(scoreMap.get(event2), scoreMap.get(event1)));

        return results;
    }

    // Clear the events in the lists and event map
    public static void clearEvents() {
        eventArrayList.clear();
        eventMap.clear();
    }



    // GETTER METHODS
    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getDate() {
        return date;
    }

    public boolean getDelInd() {
        return delInd;
    }

    // SETTER METHODS
    public void setId(int id) {
        // remove the id from hash map if updated
        eventMap.remove(this.id);
        this.id = id;
        // Add the new id to hash map
        eventMap.put(this.id, this);
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDelInd(boolean delInd) {
        this.delInd = delInd;
    }


}
