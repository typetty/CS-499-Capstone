package com.example.finalprojecttypetty;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {

    private final List<Event> events;
    public EventAdapter(Context context, List<Event> events) {
        super(context, 0, events);
        this.events = new ArrayList<>(events);
    }

    // Update the events list when the user searches
    public void updateEvents(List<Event> newEvents) {
        // clear and update the event list with the new filtered events
        events.clear();
        events.addAll(newEvents);

        // Since we are extending the ArrayAdapter for EventAdapter, we need to clear that list as well and update it with the new events
        clear();
        addAll(events);

        // Make sure the list view is updated to match accordingly
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Event event = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Set the text to include the new event details
        TextView name = convertView.findViewById(R.id.eventTitle);
        TextView location = convertView.findViewById(R.id.eventLocation);
        TextView date = convertView.findViewById(R.id.eventDate);

        name.setText(event.getName());
        location.setText(event.getLocation());
        date.setText(event.getDate().toString());

        // Update the view
        return convertView;
    }




}
