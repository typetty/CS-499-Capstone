package com.example.finalprojecttypetty;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SQLiteManager extends SQLiteOpenHelper {
    // Declare global variables
    private static SQLiteManager sqLiteManager;
    public static String LOGIN_EXTRA = "loginUser";

    // Database variables
    private static final String DB_NAME = "EventDB";
    private static final int DB_VERSION = 2;
    private static final String USER_TABLE = "User";
    private static final String EVENT_TABLE = "Event";
    private static final String COUNTER = "Counter";

    // Event table variables
    private static final String ID_FIELD = "id";
    private static final String EVENT_UID_FIELD = "user_id";
    private static final String NAME_FIELD = "name";
    private static final String LOCATION_FIELD = "location";
    private static final String DATE_FIELD = "date";
    private static final String DELETE_INDICATOR = "delete_indicator";

    // User table variables
    private static final String USER_ID_FIELD = "id";
    private static final String USER_USERNAME_FIELD = "username";
    private static final String USER_PASSWORD_FIELD = "password";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

    // Constructor
    public SQLiteManager(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // make sure you use the current instance of the object before instantiating a new one
    public static SQLiteManager instanceOfDatabase(Context context) {
//        context.deleteDatabase(DB_NAME);
        if (sqLiteManager == null) {
            sqLiteManager = new SQLiteManager(context);
        }
        return sqLiteManager;
    }

    // |---------------|
    // | CREATE TABLES |
    // |---------------|
    @Override
    public void onCreate(SQLiteDatabase db) {
//        close();

        // Enforce the foreign key checks on the database for users to only get their records
        db.execSQL("PRAGMA foreign_keys=ON;");

        // Build the user table
        StringBuilder userSql;
        userSql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(USER_TABLE)
                .append("(")
                .append(USER_ID_FIELD)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USER_USERNAME_FIELD)
                .append(" TEXT UNIQUE, ")
                .append(USER_PASSWORD_FIELD)
                .append(" TEXT)");

        db.execSQL(userSql.toString());

        // Build the Event table
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(EVENT_TABLE)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(EVENT_UID_FIELD)
                .append(" INTEGER, ")
                .append(NAME_FIELD)
                .append(" TEXT, ")
                .append(LOCATION_FIELD)
                .append(" TEXT, ")
                .append(DATE_FIELD)
                .append(" TEXT, ")
                .append(DELETE_INDICATOR)
                .append(" INT, ")
                .append("FOREIGN KEY(")
                .append(EVENT_UID_FIELD)
                .append(") REFERENCES ")
                .append(USER_TABLE)
                .append("(")
                .append(USER_ID_FIELD)
                .append("))");

        db.execSQL(sql.toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the tables and recreate them on update
        db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        onCreate(db);
    }


    // |----------------|
    // | USER FUNCTIONS |
    // |----------------|
    // Add an event to the database
    public void addEventToDB(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(EVENT_UID_FIELD, event.getUserId());
        contentValues.put(NAME_FIELD, event.getName());
        contentValues.put(LOCATION_FIELD, event.getLocation());
        contentValues.put(DATE_FIELD, event.getDate());
        contentValues.put(DELETE_INDICATOR, 0);

        db.insert(EVENT_TABLE, null, contentValues);
    }

    // Update an event to the database
    public void updateEventToDB(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(EVENT_UID_FIELD, event.getUserId());
        contentValues.put(NAME_FIELD, event.getName());
        contentValues.put(LOCATION_FIELD, event.getLocation());
        contentValues.put(DATE_FIELD, event.getDate());
        contentValues.put(DELETE_INDICATOR, getIntFromBool(event.getDelInd()));

        db.update(EVENT_TABLE, contentValues, ID_FIELD + "=?", new String[]{String.valueOf(event.getId())});
    }

    // Fill in the list of events for the current user
    public void populateEventListArray(int userId) {
        // clear the list at the beginning of query
        Event.clearEvents();

        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor result = db.rawQuery("SELECT * FROM " + EVENT_TABLE + " WHERE " + EVENT_UID_FIELD + "=" + userId + " AND " + DELETE_INDICATOR + "=0", null)) {
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    int id = result.getInt(1);
                    int uid = result.getInt(2);
                    String name = result.getString(3);
                    String location = result.getString(4);
                    String date = result.getString(5);
                    boolean delInd = getBoolFromInt(result.getInt(6));


                    // Create the event and add it to the list
                    Event event = new Event(id, uid, name, location, date, delInd);
                    Event.eventArrayList.add(event);
                }
            }
        }


    }

    // |----------------|
    // | USER FUNCTIONS |
    // |----------------|

    // Hash the password to store and compare
    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256"); // Use SHA rather than AES because AES is symmetrical encryption
            byte[] bytes = md.digest(password.getBytes());

            StringBuilder hash = new StringBuilder();
            for (byte b : bytes) {
                String tempString = Integer.toHexString(0xff & b);
                if (tempString.length() == 1) {
                    hash.append('0');
                }
                hash.append(tempString);
            }

            return hash.toString(); // Return the final hash value

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Add a user to the database
    public void insertUserRecord(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_USERNAME_FIELD, username);
        contentValues.put(USER_PASSWORD_FIELD, encryptPassword(password));

        db.insert(USER_TABLE, null, contentValues);
    }

    // Create a new user
    public int createNewUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        try (Cursor result = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE " + USER_USERNAME_FIELD + " = ?", new String[]{username})) {
            if (result.getCount() != 0) {
                return -400; // error for if username already exists.
            } else {
                insertUserRecord(username, password);
                try (Cursor result2 = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE " + USER_USERNAME_FIELD + " = ?", new String[]{username})) {
                    result2.moveToFirst();
                    int currentId = result2.getInt(0);
                    return currentId;
                }
            }
        }

    }

    // Login in for a user
    public int loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        try (Cursor result = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE " + USER_USERNAME_FIELD + " = ?", new String[]{username})) {
            if (result.getCount() == 0) {
                return -400; // error for if username doesn't exists.
            } else {
                result.moveToFirst();
                int currentId = result.getInt(0);
                String currentPassword = result.getString(2);
                if (currentPassword.equals(encryptPassword(password))) {
                    return currentId;
                } else {
                    return -401; // error for is password is wrong
                }
            }
        }
    }

    // Update the username if the user requests it
    public int updateUsername(int userId, String newUsername) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if username already exists in db
        try (Cursor result = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE " + USER_USERNAME_FIELD + " = ?", new String[]{newUsername})) {
            if (result.getCount() != 0) {
                return -400; // return error if username already exists
            }
        }

        // If no error, try to edit the username.
        ContentValues values = new ContentValues();
        values.put(USER_USERNAME_FIELD, newUsername);
        int rowsUpdated = db.update(USER_TABLE, values, USER_ID_FIELD + "=?", new String[]{String.valueOf(userId)});

        return rowsUpdated > 0 ? userId : -1;
    }

    // Update Password if the user requests it
    public int updatePassword(int userId, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Since we don't need to compare the passwords, we can simply write over the existing value
        ContentValues values = new ContentValues();
        values.put(USER_PASSWORD_FIELD, encryptPassword(newPassword));
        int rowsUpdated = db.update(USER_TABLE, values, USER_ID_FIELD + "=?", new String[]{String.valueOf(userId)});

        return rowsUpdated > 0 ? userId : -1;
    }

    // Convert bool to int
    private boolean getBoolFromInt(int i) {
        if (i == 1) {
            return true;
        } else {
            return false;
        }
    }

    // Convert int to bool
    private int getIntFromBool(boolean bool) {
        if (bool) {
            return 1;
        } else {
            return 0;
        }
    }

}
