package com.example.finalprojecttypetty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Declare global variables here for this class
    Button btnRegister;
    Button btnLogin;
    EditText username;
    EditText password;
    TextView error;
    UserService userService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set content view
        setContentView(R.layout.login);

        // Assign each variable to its corresponding UI piece
        btnRegister = findViewById(R.id.buttonRegister);
        btnLogin = findViewById(R.id.buttonLogin);
        username = findViewById(R.id.usernameField);
        password = findViewById(R.id.passwordField);
        error = findViewById((R.id.errorText));

        // Initialize UserService object
        userService = new UserService(this);
    }

    // |-----------------|
    // | REGISTER METHOD |
    // |-----------------|
    public void onClickRegister(View view) {
        // On new click, make the error invisible
        error.setVisibility(View.INVISIBLE);

        // Use the UserResult method in the UserService class to verify credentials
        UserService.UserResult result = userService.register(username.getText().toString(), password.getText().toString());

        // Show error message to user if failed
        if (!result.success) {
            error.setText(result.errorMessage);
            error.setVisibility(View.VISIBLE);
            return;
        }

        // Navigate to EventListActivity once logged in with new credentials
        Intent loginIntent =
                new Intent(MainActivity.this, EventListActivity.class);
        // Send the userid through the intent for the next context to have it
        loginIntent.putExtra(SQLiteManager.LOGIN_EXTRA, result.userId);
        startActivity(loginIntent);
    }

    // |--------------|
    // | LOGIN METHOD |
    // |--------------|
    public void onClickLogin(View view) {

        // On new click, make the error invisible
        error.setVisibility(View.INVISIBLE);

        // Use the UserResult method in the UserService class to verify credentials
        UserService.UserResult result = userService.login(username.getText().toString(), password.getText().toString());

        // Show error message to user if failed
        if (!result.success) {
            error.setText(result.errorMessage);
            error.setVisibility(View.VISIBLE);
            return;
        }

        // Navigate to EventListActivity once logged in with new credentials
        Intent loginIntent =
                new Intent(MainActivity.this, EventListActivity.class);
        // Send the userid through the intent for the next context to have it
        loginIntent.putExtra(SQLiteManager.LOGIN_EXTRA, result.userId);
        startActivity(loginIntent);
    }
}
