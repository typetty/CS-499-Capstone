package com.example.finalprojecttypetty;

import android.content.Context;

public class UserService {

    private final SQLiteManager db;

    // constructor
    public UserService(Context context) {
        db = SQLiteManager.instanceOfDatabase(context);
    }

    // |---------------|
    // | RESULT OBJECT |
    // |---------------|
    public static class UserResult {
        public boolean success;
        public String errorMessage;
        public int userId;

        public UserResult(boolean success, String errorMessage, int userId) {
            this.success = success;
            this.errorMessage = errorMessage;
            this.userId = userId;
        }
    }

    // |----------|
    // | REGISTER |
    // |----------|
    public UserResult register(String username, String password) {

        // Check if the username or password are blank. Must be filled in to register.
        if (username.isBlank() || password.isBlank()) {
            return new UserResult(false, "Please enter a valid username and password to register.", -1);
        }

        // If there is a value in each, then try to create a new user record on the db.
        int newUserId = db.createNewUser(username, password);

        // If a user with the given username already exists, an error will occur.
        if (newUserId == -400) {
            return new UserResult(false, "Please enter a different username, it already exists.", -1);
        }

        return new UserResult(true, null, newUserId);
    }

    // |-------|
    // | LOGIN |
    // |-------|
    public UserResult login(String username, String password) {

        // Check if the username or password are blank. Must be filled in to register.
        if (username.isBlank() || password.isBlank()) {
            return new UserResult(false, "Please enter a valid username and password to login.", -1);
        }

        // If there is a value in each, then try to login to the user record on the db.
        int userId = db.loginUser(username, password);

        // If a user with the given username doesn't exists, an error will occur.
        if (userId == -400) {
            return new UserResult(false, "The provided username doesn't exist.", -1);
        }

        // If the password is incorrect for the user, a different error will be thrown.
        if (userId == -401) {
            return new UserResult(false, "The password is incorrect. Please try again.", -1);
        }

        return new UserResult(true, null, userId);
    }


    public UserResult updateUsername(int userId, String newUsername) {

        // Check if the username is blank and then return an error if it is
        if (newUsername == null || newUsername.isBlank()) {
            return new UserResult(false, "Username cannot be empty.", -1);
        }

        int result = db.updateUsername(userId, newUsername);

        if (result == -400) { // Check for error that username already exists.
            return new UserResult(false, "Username already exists.", -1);
        }

        if (result == -1) { // Check for another error
            return new UserResult(false, "Failed to update username.", -1);
        }

        // If it passed everything else, we can send a success.
        return new UserResult(true, null, userId);
    }

    public UserResult updatePassword(int userId, String newPassword) {

        // Check if the username is blank and then return an error if it is
        if (newPassword == null || newPassword.isBlank()) {
            return new UserResult(false, "Password cannot be empty.", -1);
        }

        int result = db.updatePassword(userId, newPassword);

        if (result == -1) { // Check if an error occurs updating the password to the db
            return new UserResult(false, "Failed to update password.", -1);
        }

        // If it passed everything else, we can send a success.
        return new UserResult(true, null, userId);
    }
}